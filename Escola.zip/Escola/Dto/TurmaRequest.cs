﻿using Escola.Model;
using System.ComponentModel.DataAnnotations;

namespace Escola.Dto
{
    public class TurmaRequest
    {
        [MinLength(1)]
        public string? Sala { get; set; }

        [Required]
        public int EstudanteId { get; set; }

        public Turma toModel()
            => new Turma(Sala, EstudanteId);
    }
}
