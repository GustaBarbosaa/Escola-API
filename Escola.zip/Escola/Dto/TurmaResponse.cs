﻿using Escola.Model;

namespace Escola.Dto
{
    public class TurmaResponse
    {
        public string? Serie { get; set; }
        public Estudante Estudante { get; set; }
        public TurmaResponse(Turma turma)
        {
            Serie = turma.Serie;
            Estudante = turma.Estudante;
        }


    }
}
