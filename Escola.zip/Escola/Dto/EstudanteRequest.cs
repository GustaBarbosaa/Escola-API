﻿using Escola.Model;
using System.ComponentModel.DataAnnotations;

namespace Escola.Dto
{
    public class EstudanteRequest
    {
        [MinLength(1)]
        public string? Nome { get; set; }

        public Estudante toModel()
            => new Estudante(Nome);
    }
}
