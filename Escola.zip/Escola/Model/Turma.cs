﻿using System.ComponentModel.DataAnnotations;

namespace Escola.Model
{
    public class Turma
    {
        [Key]
        public int Id { get; set; }
        public string? Serie { get; set; }
        public int EstudanteId { get; set; }
        public Estudante Estudante { get; set; }

        public Turma(string? serie, int estudanteId)
        {
            Serie = serie;
            EstudanteId = estudanteId;
        }
    }
}
