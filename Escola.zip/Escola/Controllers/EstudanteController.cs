﻿using Escola.Context;
using Escola.Dto;
using Escola.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Escola.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EstudanteController : ControllerBase
    {
        private readonly DataContext _dataContext;

        public EstudanteController()
        {
            _dataContext = new DataContext();
        }

        // GET: api/<CategoriaController>
        [HttpGet]
        public ActionResult<List<Estudante>> Get()
        {
            var estudantes = _dataContext.Estudante.ToList<Estudante>();
            return estudantes;
        }

        // GET api/<CategoriaController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<CategoriaController>
        [HttpPost]
        public ActionResult<Estudante> Post([FromBody] EstudanteRequest estudanteRequest)
        {
            if (ModelState.IsValid)
            {
                var estudante = estudanteRequest.toModel();
                _dataContext.Estudante.Add(estudante);
                _dataContext.SaveChanges();
                return estudante;
            }
            return BadRequest(ModelState);
        }

        // PUT api/<CategoriaController>/5
        [HttpPut]
        public ActionResult<Estudante> Put([FromBody] Estudante estudante)
        {
            var estudanteENulo = _dataContext.Estudante.FirstOrDefault(estudante) == null;
            if (estudanteENulo)
                ModelState.AddModelError("EstudanteId", "Id do estudante não encontrado!");

            if (ModelState.IsValid)
            {
                _dataContext.Estudante.Update(estudante);
                _dataContext.SaveChanges();
                return estudante;
            }
            return BadRequest(ModelState);

        }

        // DELETE api/<CategoriaController>/5
        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            var estudante = _dataContext.Estudante.Find(id);
            if (estudante == null)
                ModelState.AddModelError("EstudanteId", "Id do estudante não encontrado!");

            if (ModelState.IsValid)
            {
                _dataContext.Estudante.Remove(estudante);
                _dataContext.SaveChanges();
                return Ok();
            }
            return BadRequest(ModelState);
        }
    }
}
