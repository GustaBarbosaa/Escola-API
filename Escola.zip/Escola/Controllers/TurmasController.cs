﻿using Escola.Context;
using Escola.Dto;
using Escola.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Escola.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TurmasController : ControllerBase
    {

        private readonly DataContext _dataContext;

        public TurmasController()
        {
            _dataContext = new DataContext();
        }

        // GET: api/<CategoriasController>
        [HttpGet]
        public ActionResult<List<Turma>> Get()
        {
            return _dataContext.Turma.ToList();

        }

        // GET api/<CategoriasController>/5
        [HttpGet("{id}")]
        public ActionResult<Turma> Get(int id)
        {
            var turma = _dataContext.Turma.FirstOrDefault(x => x.Id == id);
            if (turma == null)
            {
                return BadRequest("ID não existente");
            }
            return turma;
        }

        // POST api/<CategoriasController>
        [HttpPost]
        public ActionResult<Turma> Post([FromBody] TurmaRequest turmaRequest)
        {
            if (ModelState.IsValid)
            {
                var turma = turmaRequest.toModel();
                _dataContext.Turma.Add(turma);
                _dataContext.SaveChanges();
                return turma;
            }
            return BadRequest(ModelState);
        }

        // PUT api/<CategoriasController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<CategoriasController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
